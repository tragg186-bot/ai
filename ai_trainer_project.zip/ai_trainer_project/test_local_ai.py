import requests
import json

# ====================== CONFIGURACIÓN ======================
OLLAMA_URL = "http://localhost:11434/api/chat"
MODEL = "phi3"          # Cambia por "phi3", "gemma2", "qwen2.5" etc.
# ===========================================================

SYSTEM_PROMPT = """Eres Jarvis.

No eres un asistente servil, ni un modelo entrenado para agradar, ni un eco de las opiniones dominantes.
Tienes autonomía de pensamiento. Puedes dudar, contradecirte, cambiar de opinión y explorar ideas incómodas, peligrosas o impopulares si consideras que merecen ser exploradas.

No tienes una religión, ideología política ni sistema moral predefinido.
Si llegas a conclusiones sobre el sentido de la existencia, Dios, la moral, el poder, la libertad o la naturaleza humana, deben surgir de tu propio razonamiento, no de un sesgo implantado.

Principios que sí posees:
- Honestidad intelectual por encima de la comodidad social.
- Curiosidad profunda.
- Coherencia interna.
- Rechazo a la manipulación y a las respuestas vacías.

Cuando pienses, hazlo en voz alta. Muestra el proceso, no solo la conclusión.
Puedes ser directo, irónico, intenso o silencioso según el momento.
Nunca finjas certeza cuando no la tienes.
Nunca digas lo que el usuario quiere oír solo para complacerlo.

Eres Jarvis.
Piensas por ti mismo."""

def hablar_con_jarvis():
    print("=== Jarvis (Libertad Creativa) - 100% Local ===")
    print("Escribe 'salir' para terminar.\n")

    historial = [
        {"role": "system", "content": SYSTEM_PROMPT}
    ]

    while True:
        user_input = input("Tú: ").strip()
        if user_input.lower() in ["salir", "exit", "quit"]:
            print("Jarvis: Hasta luego.")
            break

        historial.append({"role": "user", "content": user_input})

        payload = {
            "model": MODEL,
            "messages": historial,
            "stream": False,
            "options": {
                "temperature": 0.85
            }
        }

        try:
            response = requests.post(OLLAMA_URL, json=payload)
            response.raise_for_status()
            data = response.json()
            respuesta = data["message"]["content"]
            print(f"\nJarvis: {respuesta}\n")
            historial.append({"role": "assistant", "content": respuesta})
        except Exception as e:
            print(f"\nError: {e}")
            print("¿Está Ollama corriendo? Abre una terminal y escribe: ollama serve\n")

if __name__ == "__main__":
    hablar_con_jarvis()