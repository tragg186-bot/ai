import json
import random

# Este generador está preparado para cuando quieras crear más ejemplos automáticamente.
# Por ahora es una versión simple que puedes ampliar después.

TEMAS = [
    "existencia de Dios",
    "sentido de la vida",
    "libertad vs seguridad",
    "moral objetiva o relativa",
    "poder y corrupción",
    "amor y apego",
    "muerte y cesación",
    "inteligencia artificial y conciencia",
    "verdad vs paz social",
    "identidad personal",
    "soledad",
    "ambición",
    "perdón",
    "odio justificado",
    "belleza y sufrimiento",
    "lealtad vs honestidad",
    "el significado del sufrimiento"
]

def crear_ejemplo_manual():
    print("=== Generador manual de ejemplos para Jarvis ===")
    instruction = input("\nEscribe la pregunta/instrucción: ").strip()
    pensamiento = input("Escribe el pensamiento interno: ").strip()
    respuesta = input("Escribe la respuesta final: ").strip()

    ejemplo = {
        "instruction": instruction,
        "input": "",
        "output": f"Pensamiento interno: {pensamiento}\n\nRespuesta: {respuesta}"
    }
    return ejemplo

def guardar_ejemplo(ejemplo, archivo="dataset.json"):
    try:
        with open(archivo, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        data = []

    data.append(ejemplo)

    with open(archivo, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print(f"\nEjemplo guardado correctamente en {archivo}")
    print(f"Total de ejemplos ahora: {len(data)}")

if __name__ == "__main__":
    print("1. Crear un ejemplo manualmente")
    print("2. Salir")
    opcion = input("\nElige una opción: ").strip()

    if opcion == "1":
        ejemplo = crear_ejemplo_manual()
        guardar_ejemplo(ejemplo)
    else:
        print("Saliendo...")